import logo from './logo.svg';
import './App.css';
import { Component } from 'react';
import StudentList from './StudentList'

class App extends Component{
   render(){
   
   return(
     <>
     <StudentList/>
     </>
   )
  }
}

export default App;
