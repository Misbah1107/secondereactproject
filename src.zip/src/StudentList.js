import { Component } from 'react';
class Students extends Component{
    render(){
    this.state = {
      student1: ['Name: Misbah', 'Education: Inter', 'Age: 21'],
      student2: ['Name: Uroosa', 'Education: Matric', 'Age: 18'],
      student3: ['Name: Hiba', 'Education: B.A', 'Age: 25']
    }
    
    return(
      <>
      <h1>Student = 1</h1>
      <h3>{this.state.student1.map((item1) =>(
        <p>{item1}</p>
      ))}</h3>
 <br/>
 
      <h1>Student = 2</h1>
      <h3>{this.state.student2.map((item2) =>(
        <p>{item2}</p>
      ))}</h3>
 <br/>
 
       <h1>Student = 3</h1>
      <h3>{this.state.student3.map((item3) =>(
        <p>{item3}</p>
      ))}</h3>


      </>
    )
   }
 }

 export default Students;